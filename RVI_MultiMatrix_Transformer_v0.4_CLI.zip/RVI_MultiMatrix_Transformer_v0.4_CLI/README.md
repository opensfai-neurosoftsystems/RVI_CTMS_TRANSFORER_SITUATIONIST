# RVI Multi-Matrix Transformer v0.3

The next transformer in the RVI/CTMS line.

This build begins from the supplied v0.1 RVI Transformer and changes the central
architectural object from **one relational field** to **one object with multiple
simultaneous relational addresses**.

The original prototype is preserved in `legacy_v01/`.

`kernel/CTMS.md` is copied unchanged and remains the canonical CTMS source.

---

## 1. Architecture

```text
UTF-8 BYTES / TOKENS
        ↓
TOKEN STATE
        ↓
MULTI-MATRIX PROJECTOR
        │
        ├─ semantic
        ├─ temporal
        ├─ spatial
        ├─ causal
        ├─ embodied
        ├─ media
        ├─ lineage
        ├─ contradiction
        ├─ operator
        └─ provenance
        ↓
MATRIX ROUTER (top-k per token)
        ↓
CROSS-MATRIX COMPLEX RVI
        ↓
EXPLICIT RELATIONAL FIELD [B,H,T,T]
        ↓
CTMS DIFFERENTIABLE REFINER
        ↓
ATTENTION
        ↓
PERSISTENT RELATIONAL MEMORY
        ↓
TOKEN DECODER
        ├─ tokens
        └─ optional encoder → Neural DAC → PCM
```

---

## 2. The central change

v0.1:

```text
hidden state
    ↓
amplitude / phase
    ↓
one RVI field
```

v0.3:

```text
hidden state
    ↓
M meaning-matrix states
    ↓
token-specific matrix routing
    ↓
head-specific matrix-to-matrix coupling
    ↓
complex RVI collision
    ↓
one explicit field carrying cross-matrix interaction
```

The implementation avoids materializing a dense:

```text
[B,M,M,H,T,T]
```

tensor.

Instead, cross-matrix mixing happens in complex latent coordinates before the
token-token relational field is constructed.

---

## 3. Multi-matrix meaning

A token/passsage can simultaneously have addresses in:

```text
semantic
temporal
spatial
causal
embodied
media
lineage
contradiction
operator
provenance
```

The matrix names are configuration, not kernel law.

The `MultiMatrixMeaningIndex` keeps those spaces independently queryable outside
the model as well.

---

## 4. RVI collision

For every matrix the model learns amplitude and phase coordinates:

```text
z = a · exp(iφ)
```

A head-specific matrix coupling transforms the matrix population:

```text
z'_m = Σ_n C[h,m,n] z_n
```

The token router then selects a mixture:

```text
z_eff(t) = Σ_m g[t,m] z'_m(t)
```

and the explicit relational field is generated from the resulting complex state
with a learned lag.

This allows **cross-matrix interference** without storing an M×M token-pair field.

---

## 5. CTMS boundary

There are two different things called CTMS in the project and v0.3 keeps them separate:

### Canonical CTMS
`kernel/CTMS.md`

Domain-agnostic traversal discipline.

### Differentiable CTMS analogue
`CTMSRefiner` and `CTMSOperatorRouter`

Trainable in-network operators that modulate recursion and REDCHECK-like
relational disagreement.

The differentiable analogue does not replace or redefine the canonical kernel.

---

## 6. Persistent relational memory

`RelationalMemory.matrix_summary` is:

```text
[B,M,Dm]
```

It is compressed rather than a historical T×T field.

The same memory can be passed into a later chunk:

```python
logits, loss, diag, memory = model(
    chunk_a,
    targets_a,
    return_diagnostics=True,
    return_memory=True,
)

logits, loss, diag, memory = model(
    chunk_b,
    targets_b,
    memory=memory.detach(),
    return_diagnostics=True,
    return_memory=True,
)
```

This is not yet a production KV cache. It is the first explicit cross-chunk RVI
memory surface.

---

## 7. "Catch time on the wing"

The loss is no longer only next-byte cross entropy.

v0.3 can combine:

```text
L = L_language
  + λm L_matrix
  + λo L_operator
  + λt L_transition
  + λd L_diversity
```

`L_transition` predicts the next hidden state from the current one. It is the
first explicit training objective for **becoming / transition**, rather than only
classification of the static state.

---

## 8. Annotated corpus

Plain text still works:

```bash
python train.py --text corpus.txt
```

But the intended teaching format is JSONL:

```json
{
  "id": "TD-001:000001",
  "text": "passage",
  "matrices": ["semantic", "temporal", "contradiction"],
  "operator": "REDCHECK",
  "metadata": {
    "document_id": "TD-001",
    "page": 42
  }
}
```

Train it with:

```bash
python train.py --jsonl corpus/train.jsonl --steps 2000
```

Documents remain source documents. The matrix/operator layer is an address and
training layer around them.

---

## 9. External meaning index

After training:

```bash
python index_corpus.py \
  --checkpoint checkpoint_v03.pt \
  --jsonl corpus/train.jsonl \
  --out meaning_index.pt
```

The index supports matrix-weighted retrieval, including explicit contradiction
retrieval.

---

## 10. Ablations

```bash
python ablate.py --text corpus.txt --steps 300
```

Profiles:

```text
baseline = ordinary transformer
rvi      = single-field legacy RVI + CTMS
matrix   = multi-matrix routing without RVI
full     = multi-matrix + cross-matrix RVI + CTMS
```

The harness reports parameter counts. A true matched-FLOP / matched-parameter
benchmark remains required before architectural claims.

---

## 11. Encoder and DAC

The package includes:

```text
RVIMultiMatrixEncoder
NeuralDAC
```

The DAC produces normalized digital PCM for ordinary sensory/audio rendering.
It is not a direct neural-stimulation driver.

---

## 12. Smoke tests

```bash
python tests/smoke_test.py
python tests/test_index.py
```

---

## 13. What v0.3 does not claim

This prototype does not establish that:

- transformer attention is physical wave interference;
- the named meaning matrices are uniquely correct;
- multi-matrix RVI improves language modeling;
- CTMS recursion is superior to additional transformer depth;
- compressed matrix memory is equivalent to a production KV cache;
- a biological brain uses this architecture.

Those are experiments.

The purpose of v0.3 is to make the proposed architecture explicit enough to
ablate.


---

## 14. Complete CLI

v0.4 adds an installable command-line operator surface:

```bash
pip install -e .
ctms doctor --smoke
ctms --help
```

The alias `rvi` invokes the same CLI.

The full operator manual is:

```text
docs/CLI_MANUAL.md
```

Read it in the terminal:

```bash
ctms manual show
ctms manual search "matrix collapse"
```

The CLI covers kernel inspection, configuration, corpus validation and splitting,
training, generation, checkpoint comparison, matrix routing, CTMS operator
routing, relational memory, structured traces, meaning-index build/query, DAC
rendering, ablation and benchmarking.

The canonical `kernel/CTMS.md` remains unchanged.
