"""
Ablation harness for the v0.3 architecture.

Profiles:
  A0 baseline     = ordinary transformer
  A1 rvi          = legacy RVI + CTMS, no multi-matrix
  A2 matrix       = multi-matrix routing, no RVI
  A3 full         = multi-matrix + cross-matrix RVI + CTMS

This harness reports parameter counts; it is a structural ablation,
not yet a parameter-matched-compute benchmark.
"""

import argparse
import copy
import json
from pathlib import Path

import torch

from rvi_multimatrix import RVIMultiMatrixTransformer, RVIConfig, ByteTokenizer


def batch(data, bs, sl, device):
    ix = torch.randint(0, len(data) - sl - 1, (bs,))
    x = torch.stack([data[i:i + sl] for i in ix]).to(device)
    y = torch.stack([data[i + 1:i + sl + 1] for i in ix]).to(device)
    return x, y


def run(cfg, train_data, val_data, steps, bs, sl, device, seed):
    torch.manual_seed(seed)
    model = RVIMultiMatrixTransformer(cfg).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=3e-4)

    model.train()
    for _ in range(steps):
        x, y = batch(train_data, bs, sl, device)
        _, loss = model(x, y)
        opt.zero_grad(set_to_none=True)
        loss.backward()
        opt.step()

    model.eval()
    vals = []
    with torch.no_grad():
        for _ in range(10):
            x, y = batch(val_data, bs, sl, device)
            _, loss = model(x, y)
            vals.append(loss.item())

    return sum(vals) / len(vals), sum(p.numel() for p in model.parameters())


def profile(base, name):
    d = copy.deepcopy(base)
    if name == "baseline":
        d.update(rvi_enabled=False, multimatrix_enabled=False, ctms_enabled=False)
    elif name == "rvi":
        d.update(rvi_enabled=True, multimatrix_enabled=False, ctms_enabled=True)
    elif name == "matrix":
        d.update(rvi_enabled=False, multimatrix_enabled=True, ctms_enabled=False)
    elif name == "full":
        d.update(rvi_enabled=True, multimatrix_enabled=True, ctms_enabled=True)
    else:
        raise ValueError(name)
    return RVIConfig(**d)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--text", required=True)
    ap.add_argument("--config", default="config.json")
    ap.add_argument("--steps", type=int, default=200)
    ap.add_argument("--batch-size", type=int, default=4)
    ap.add_argument("--seq-len", type=int, default=128)
    ap.add_argument("--seed", type=int, default=1337)
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = ap.parse_args()

    tok = ByteTokenizer()
    data = torch.tensor(
        tok.encode(Path(args.text).read_text(encoding="utf-8")),
        dtype=torch.long,
    )
    cut = int(len(data) * 0.9)
    tr, va = data[:cut], data[cut:]
    base = json.loads(Path(args.config).read_text())

    for name in ["baseline", "rvi", "matrix", "full"]:
        loss, n = run(
            profile(base, name),
            tr, va,
            args.steps,
            args.batch_size,
            args.seq_len,
            args.device,
            args.seed,
        )
        print(f"{name:8s} val_loss={loss:.4f} params={n:,}")


if __name__ == "__main__":
    main()
