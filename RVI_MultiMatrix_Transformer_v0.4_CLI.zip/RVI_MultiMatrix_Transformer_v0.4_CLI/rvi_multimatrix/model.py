from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Tuple, List, Dict, Sequence
import math

import torch
import torch.nn as nn
import torch.nn.functional as F


DEFAULT_MATRICES = [
    "semantic",
    "temporal",
    "spatial",
    "causal",
    "embodied",
    "media",
    "lineage",
    "contradiction",
    "operator",
    "provenance",
]

CTMS_OPERATORS = [
    "SEED",
    "BLOOM",
    "FORK",
    "RECURSE",
    "REDCHECK",
    "FLATTEN",
    "TRANSMIT",
]


@dataclass
class RVIConfig:
    # Base transformer
    vocab_size: int = 256
    d_model: int = 256
    n_heads: int = 8
    n_layers: int = 6
    d_ff: int = 1024
    max_seq_len: int = 512
    dropout: float = 0.0

    # RVI
    rvi_enabled: bool = True
    rvi_rank: int = 32
    rvi_alpha: float = 0.35
    rvi_beta: float = 0.15

    # Multi-matrix meaning index
    multimatrix_enabled: bool = True
    matrix_names: List[str] = field(default_factory=lambda: list(DEFAULT_MATRICES))
    matrix_dim: int = 64
    matrix_top_k: int = 4
    matrix_residual_alpha: float = 0.20

    # CTMS differentiable routing/refinement
    ctms_enabled: bool = True
    ctms_recurse: int = 2
    operator_names: List[str] = field(default_factory=lambda: list(CTMS_OPERATORS))

    # Persistent compressed relational memory
    memory_decay: float = 0.85

    # Auxiliary training objectives
    matrix_loss_weight: float = 0.10
    operator_loss_weight: float = 0.10
    transition_loss_weight: float = 0.05
    diversity_loss_weight: float = 0.01

    @property
    def n_matrices(self) -> int:
        return len(self.matrix_names)

    @property
    def n_operators(self) -> int:
        return len(self.operator_names)

    def validate(self):
        assert self.d_model % self.n_heads == 0
        assert self.rvi_rank > 0
        assert self.ctms_recurse >= 1
        assert self.n_matrices >= 1
        assert self.matrix_dim >= 4
        assert 0 <= self.matrix_top_k <= self.n_matrices
        assert self.n_operators >= 1


@dataclass
class RelationalMemory:
    """
    Compressed cross-layer / cross-chunk memory.

    matrix_summary: [B,M,Dm]
    """
    matrix_summary: torch.Tensor

    def detach(self) -> "RelationalMemory":
        return RelationalMemory(self.matrix_summary.detach())


@dataclass
class MultiMatrixState:
    """
    Inspectable state emitted by CrossMatrixRVI.

    field:          [B,H,T,T]
    router:         [B,T,M]
    matrix_summary: [B,M,Dm]
    matrix_coupling:[H,M,M]
    """
    field: torch.Tensor
    router: torch.Tensor
    matrix_summary: torch.Tensor
    matrix_coupling: torch.Tensor


class RotaryEmbedding(nn.Module):
    def __init__(self, head_dim: int, max_seq_len: int = 4096, base: float = 10000.0):
        super().__init__()
        assert head_dim % 2 == 0
        inv_freq = 1.0 / (base ** (torch.arange(0, head_dim, 2).float() / head_dim))
        t = torch.arange(max_seq_len).float()
        freqs = torch.outer(t, inv_freq)
        self.register_buffer("cos", freqs.cos(), persistent=False)
        self.register_buffer("sin", freqs.sin(), persistent=False)

    def forward(self, x):
        T = x.size(-2)
        cos = self.cos[:T][None, None, :, :]
        sin = self.sin[:T][None, None, :, :]
        x1, x2 = x[..., ::2], x[..., 1::2]
        y1 = x1 * cos - x2 * sin
        y2 = x1 * sin + x2 * cos
        return torch.stack((y1, y2), dim=-1).flatten(-2)


class LegacyRVIRelationalKernel(nn.Module):
    """
    v0.1 single-field RVI retained for controlled ablation.

    I_ij = sum_r w_r a_i,r a_j,r cos(phi_i,r - phi_j,r - tau_r)
    """
    def __init__(self, cfg: RVIConfig):
        super().__init__()
        self.h = cfg.n_heads
        self.r = cfg.rvi_rank
        self.amp_proj = nn.Linear(cfg.d_model, cfg.n_heads * cfg.rvi_rank, bias=False)
        self.phase_proj = nn.Linear(cfg.d_model, cfg.n_heads * cfg.rvi_rank, bias=False)
        self.delay = nn.Parameter(torch.zeros(cfg.n_heads, cfg.rvi_rank))
        self.band_weight = nn.Parameter(torch.ones(cfg.n_heads, cfg.rvi_rank) / cfg.rvi_rank)
        self.state_gate = nn.Parameter(torch.tensor(cfg.rvi_beta))

    def forward(self, x, previous_field: Optional[torch.Tensor] = None):
        B, T, _ = x.shape
        amp = F.softplus(self.amp_proj(x)).view(B, T, self.h, self.r).transpose(1, 2)
        phase = math.pi * torch.tanh(
            self.phase_proj(x).view(B, T, self.h, self.r).transpose(1, 2)
        )

        dphi = (
            phase.unsqueeze(3)
            - phase.unsqueeze(2)
            - self.delay[None, :, None, None, :]
        )
        pair_amp = amp.unsqueeze(3) * amp.unsqueeze(2)
        w = self.band_weight[None, :, None, None, :]
        field = (pair_amp * torch.cos(dphi) * w).sum(dim=-1)
        field = field / (field.pow(2).mean(dim=-1, keepdim=True).sqrt() + 1e-6)

        if previous_field is not None and previous_field.shape == field.shape:
            gate = torch.sigmoid(self.state_gate)
            field = (1.0 - gate) * field + gate * previous_field

        return field, amp, phase


class MatrixProjector(nn.Module):
    """
    One hidden token receives simultaneous addresses in M meaning spaces.

    x [B,T,D] -> matrices [B,M,T,Dm]
    """
    def __init__(self, cfg: RVIConfig):
        super().__init__()
        self.cfg = cfg
        self.proj = nn.Linear(cfg.d_model, cfg.n_matrices * cfg.matrix_dim, bias=False)
        self.norm = nn.RMSNorm(cfg.matrix_dim)
        self.memory_gate = nn.Parameter(torch.tensor(0.0))

    def forward(
        self,
        x: torch.Tensor,
        memory: Optional[RelationalMemory] = None,
    ) -> torch.Tensor:
        B, T, _ = x.shape
        m = self.proj(x).view(B, T, self.cfg.n_matrices, self.cfg.matrix_dim)
        m = m.permute(0, 2, 1, 3).contiguous()  # [B,M,T,Dm]

        if memory is not None and memory.matrix_summary.shape[:2] == m.shape[:2]:
            g = torch.sigmoid(self.memory_gate)
            m = m + g * memory.matrix_summary[:, :, None, :]

        return self.norm(m)


class MatrixRouter(nn.Module):
    """
    Selects which meaning matrices are active for each token.

    logits: [B,T,M]
    probs:  [B,T,M]
    """
    def __init__(self, cfg: RVIConfig):
        super().__init__()
        self.cfg = cfg
        self.route = nn.Linear(cfg.d_model, cfg.n_matrices, bias=True)

    def forward(self, x: torch.Tensor):
        logits = self.route(x)
        routed = logits

        k = self.cfg.matrix_top_k
        if k and k < self.cfg.n_matrices:
            topv, topi = torch.topk(logits, k=k, dim=-1)
            routed = torch.full_like(logits, float("-inf"))
            routed.scatter_(-1, topi, topv)

        probs = torch.softmax(routed, dim=-1)
        return logits, probs


class CTMSOperatorRouter(nn.Module):
    """
    Learned control surface over the differentiable CTMS analogue.

    This is not the canonical CTMS.md kernel. It is an in-network routing signal.
    """
    def __init__(self, cfg: RVIConfig):
        super().__init__()
        self.names = list(cfg.operator_names)
        self.head = nn.Sequential(
            nn.RMSNorm(cfg.d_model),
            nn.Linear(cfg.d_model, cfg.d_model),
            nn.SiLU(),
            nn.Linear(cfg.d_model, cfg.n_operators),
        )

    def forward(self, x: torch.Tensor):
        pooled = x.mean(dim=1)
        logits = self.head(pooled)
        probs = torch.softmax(logits, dim=-1)
        return logits, probs


class CrossMatrixRVI(nn.Module):
    """
    Multi-matrix phase-sensitive collision.

    The model does NOT materialize MxM token-token fields.

    Instead:
      1. each matrix produces complex amplitude/phase coordinates;
      2. a learned head-specific MxM coupling mixes matrix coordinates;
      3. token-specific router weights select the active matrix mixture;
      4. the resulting effective complex state produces one explicit [B,H,T,T]
         relational field.

    This preserves cross-matrix interference while avoiding O(M^2 T^2) storage.
    """
    def __init__(self, cfg: RVIConfig):
        super().__init__()
        self.cfg = cfg
        H, R, M, Dm = cfg.n_heads, cfg.rvi_rank, cfg.n_matrices, cfg.matrix_dim
        self.h, self.r, self.m = H, R, M

        self.amp_proj = nn.Linear(Dm, H * R, bias=False)
        self.phase_proj = nn.Linear(Dm, H * R, bias=False)

        # Shared phase lag across routed matrix mixtures.
        self.delay = nn.Parameter(torch.zeros(H, R))
        self.band_weight = nn.Parameter(torch.ones(H, R) / R)

        # Head-specific matrix-to-matrix communication topology.
        init = torch.eye(M)[None, :, :].repeat(H, 1, 1) * 2.0
        self.matrix_mix = nn.Parameter(init)

        # Persistence across depth.
        self.state_gate = nn.Parameter(torch.tensor(cfg.rvi_beta))

        # Compressed memory update.
        decay = min(max(cfg.memory_decay, 1e-4), 1.0 - 1e-4)
        self.memory_logit = nn.Parameter(torch.tensor(math.log(decay / (1.0 - decay))))

    def forward(
        self,
        matrix_state: torch.Tensor,   # [B,M,T,Dm]
        router: torch.Tensor,         # [B,T,M]
        previous_field: Optional[torch.Tensor] = None,
        previous_memory: Optional[RelationalMemory] = None,
    ) -> Tuple[MultiMatrixState, RelationalMemory]:
        B, M, T, Dm = matrix_state.shape

        amp = F.softplus(self.amp_proj(matrix_state))
        phase = math.pi * torch.tanh(self.phase_proj(matrix_state))

        # [B,M,T,H,R] -> [B,M,H,T,R]
        amp = amp.view(B, M, T, self.h, self.r).permute(0, 1, 3, 2, 4)
        phase = phase.view(B, M, T, self.h, self.r).permute(0, 1, 3, 2, 4)

        # Complex coordinates z = a(cos(phi) + i sin(phi)).
        zc = amp * torch.cos(phase)
        zs = amp * torch.sin(phase)

        coupling = torch.softmax(self.matrix_mix, dim=-1)  # [H,M,M]

        # Cross-matrix mixing before token routing.
        zc_mix = torch.einsum("hmn,bnhtr->bmhtr", coupling, zc)
        zs_mix = torch.einsum("hmn,bnhtr->bmhtr", coupling, zs)

        # Token-specific selection of matrix mixtures.
        zc_eff = torch.einsum("btm,bmhtr->bhtr", router, zc_mix)
        zs_eff = torch.einsum("btm,bmhtr->bhtr", router, zs_mix)

        # Apply learnable lag: Re[z_i * conj(z_j) * exp(-i tau)].
        ct = torch.cos(self.delay)[None, :, None, :]
        st = torch.sin(self.delay)[None, :, None, :]

        zc_rot = zc_eff * ct + zs_eff * st
        zs_rot = zs_eff * ct - zc_eff * st

        w = self.band_weight[None, :, None, :]
        zc_rot = zc_rot * w
        zs_rot = zs_rot * w

        field = (
            torch.einsum("bhir,bhjr->bhij", zc_rot, zc_eff)
            + torch.einsum("bhir,bhjr->bhij", zs_rot, zs_eff)
        )
        field = field / (field.pow(2).mean(dim=-1, keepdim=True).sqrt() + 1e-6)

        if previous_field is not None and previous_field.shape == field.shape:
            g = torch.sigmoid(self.state_gate)
            field = (1.0 - g) * field + g * previous_field

        current_summary = matrix_state.mean(dim=2)  # [B,M,Dm]
        if previous_memory is not None and previous_memory.matrix_summary.shape == current_summary.shape:
            decay = torch.sigmoid(self.memory_logit)
            memory_summary = decay * previous_memory.matrix_summary + (1.0 - decay) * current_summary
        else:
            memory_summary = current_summary

        memory = RelationalMemory(memory_summary)
        state = MultiMatrixState(
            field=field,
            router=router,
            matrix_summary=current_summary,
            matrix_coupling=coupling,
        )
        return state, memory


class CTMSRefiner(nn.Module):
    """
    Differentiable relational recursion.

    The universal CTMS kernel remains kernel/CTMS.md.
    This module is only a trainable analogue used inside attention.
    """
    def __init__(self, cfg: RVIConfig):
        super().__init__()
        self.steps = cfg.ctms_recurse
        self.mix = nn.Parameter(torch.zeros(self.steps, cfg.n_heads))
        self.contradiction_gate = nn.Parameter(torch.zeros(self.steps, cfg.n_heads))
        self.operator_names = list(cfg.operator_names)

        self.recurse_idx = self.operator_names.index("RECURSE") if "RECURSE" in self.operator_names else None
        self.redcheck_idx = self.operator_names.index("REDCHECK") if "REDCHECK" in self.operator_names else None

    def forward(
        self,
        field: torch.Tensor,
        mask: torch.Tensor,
        operator_probs: Optional[torch.Tensor] = None,
    ):
        x = field

        if operator_probs is not None and self.recurse_idx is not None:
            recurse_strength = operator_probs[:, self.recurse_idx][:, None, None, None]
        else:
            recurse_strength = 1.0

        if operator_probs is not None and self.redcheck_idx is not None:
            red_strength = operator_probs[:, self.redcheck_idx][:, None, None, None]
        else:
            red_strength = 1.0

        for s in range(self.steps):
            probs = torch.softmax(x.masked_fill(~mask, float("-inf")), dim=-1)
            composed = probs @ probs

            disagreement = torch.tanh(x - composed)
            mix = torch.sigmoid(self.mix[s])[None, :, None, None]
            red = torch.sigmoid(self.contradiction_gate[s])[None, :, None, None]

            mix = mix * (0.5 + recurse_strength)
            red = red * (0.5 + red_strength)

            x = (1.0 - mix) * x + mix * composed - red * disagreement
            x = x.masked_fill(~mask, 0.0)

        return x


class MLP(nn.Module):
    def __init__(self, cfg: RVIConfig):
        super().__init__()
        self.fc1 = nn.Linear(cfg.d_model, 2 * cfg.d_ff, bias=False)
        self.fc2 = nn.Linear(cfg.d_ff, cfg.d_model, bias=False)

    def forward(self, x):
        a, b = self.fc1(x).chunk(2, dim=-1)
        return self.fc2(F.silu(a) * b)


class MultiMatrixAttention(nn.Module):
    def __init__(self, cfg: RVIConfig):
        super().__init__()
        cfg.validate()
        self.cfg = cfg
        self.h = cfg.n_heads
        self.dh = cfg.d_model // cfg.n_heads

        self.qkv = nn.Linear(cfg.d_model, 3 * cfg.d_model, bias=False)
        self.out = nn.Linear(cfg.d_model, cfg.d_model, bias=False)
        self.rope = RotaryEmbedding(self.dh, cfg.max_seq_len)

        self.matrix_projector = MatrixProjector(cfg) if cfg.multimatrix_enabled else None
        self.matrix_router = MatrixRouter(cfg) if cfg.multimatrix_enabled else None
        self.matrix_back = nn.Linear(cfg.matrix_dim, cfg.d_model, bias=False) if cfg.multimatrix_enabled else None

        self.cross_rvi = CrossMatrixRVI(cfg) if (cfg.multimatrix_enabled and cfg.rvi_enabled) else None
        self.legacy_rvi = LegacyRVIRelationalKernel(cfg) if (cfg.rvi_enabled and not cfg.multimatrix_enabled) else None

        self.operator_router = CTMSOperatorRouter(cfg) if cfg.ctms_enabled else None
        self.ctms = CTMSRefiner(cfg) if (cfg.ctms_enabled and cfg.rvi_enabled) else None

    def forward(
        self,
        x: torch.Tensor,
        previous_field: Optional[torch.Tensor] = None,
        memory: Optional[RelationalMemory] = None,
        causal: bool = True,
    ):
        B, T, C = x.shape
        q, k, v = self.qkv(x).chunk(3, dim=-1)

        def heads(t):
            return t.view(B, T, self.h, self.dh).transpose(1, 2)

        q, k, v = heads(q), heads(k), heads(v)
        q, k = self.rope(q), self.rope(k)

        logits = (q @ k.transpose(-2, -1)) / math.sqrt(self.dh)

        if causal:
            base_mask = torch.ones(T, T, dtype=torch.bool, device=x.device).tril()
        else:
            base_mask = torch.ones(T, T, dtype=torch.bool, device=x.device)
        mask = base_mask[None, None, :, :]

        diagnostics: Dict[str, torch.Tensor] = {}
        aux: Dict[str, Optional[torch.Tensor]] = {
            "router_logits": None,
            "operator_logits": None,
            "matrix_state": None,
            "matrix_router": None,
        }

        operator_logits = operator_probs = None
        if self.operator_router is not None:
            operator_logits, operator_probs = self.operator_router(x)
            aux["operator_logits"] = operator_logits
            diagnostics["operator_entropy"] = (
                -(operator_probs * torch.log(operator_probs + 1e-8)).sum(-1).mean().detach()
            )

        next_memory = memory
        new_field = previous_field
        matrix_context = 0.0

        if self.matrix_projector is not None:
            matrix_state = self.matrix_projector(x, memory)
            router_logits, router = self.matrix_router(x)
            aux["router_logits"] = router_logits
            aux["matrix_state"] = matrix_state
            aux["matrix_router"] = router

            diagnostics["matrix_route_entropy"] = (
                -(router * torch.log(router + 1e-8)).sum(-1).mean().detach()
            )

            # Multi-matrix residual path works even when RVI is ablated.
            routed_matrix = torch.einsum("btm,bmtd->btd", router, matrix_state)
            matrix_context = self.cfg.matrix_residual_alpha * self.matrix_back(routed_matrix)

            if self.cross_rvi is not None:
                state, next_memory = self.cross_rvi(
                    matrix_state,
                    router,
                    previous_field=previous_field,
                    previous_memory=memory,
                )
                new_field = state.field
                refined = self.ctms(new_field, mask, operator_probs) if self.ctms is not None else new_field
                new_field = refined
                logits = logits + self.cfg.rvi_alpha * refined

                diagnostics.update({
                    "rvi_field_mean": refined.mean().detach(),
                    "rvi_field_std": refined.std().detach(),
                    "matrix_coupling_entropy": (
                        -(state.matrix_coupling * torch.log(state.matrix_coupling + 1e-8))
                        .sum(-1).mean().detach()
                    ),
                    "memory_norm": next_memory.matrix_summary.norm(dim=-1).mean().detach(),
                })

        elif self.legacy_rvi is not None:
            field, amp, phase = self.legacy_rvi(x, previous_field)
            new_field = self.ctms(field, mask, operator_probs) if self.ctms is not None else field
            logits = logits + self.cfg.rvi_alpha * new_field
            diagnostics.update({
                "rvi_field_mean": new_field.mean().detach(),
                "rvi_field_std": new_field.std().detach(),
                "phase_lock": torch.cos(
                    phase.unsqueeze(3) - phase.unsqueeze(2)
                ).mean().detach(),
            })

        logits = logits.masked_fill(~mask, float("-inf"))
        attn = torch.softmax(logits, dim=-1)
        attn = F.dropout(attn, p=self.cfg.dropout, training=self.training)

        y = attn @ v
        y = y.transpose(1, 2).contiguous().view(B, T, C)
        y = self.out(y)

        if isinstance(matrix_context, torch.Tensor):
            y = y + matrix_context

        return y, new_field, next_memory, diagnostics, aux


class Block(nn.Module):
    def __init__(self, cfg: RVIConfig):
        super().__init__()
        self.n1 = nn.RMSNorm(cfg.d_model)
        self.attn = MultiMatrixAttention(cfg)
        self.n2 = nn.RMSNorm(cfg.d_model)
        self.mlp = MLP(cfg)

    def forward(self, x, previous_field=None, memory=None, causal=True):
        a, field, memory, diag, aux = self.attn(
            self.n1(x),
            previous_field=previous_field,
            memory=memory,
            causal=causal,
        )
        x = x + a
        x = x + self.mlp(self.n2(x))
        return x, field, memory, diag, aux


class RVIMultiMatrixTransformer(nn.Module):
    """
    Decoder-only RVI Multi-Matrix Transformer v0.3.

    Core state hierarchy:
      token state
        -> multiple meaning-matrix addresses
        -> learned matrix routing
        -> cross-matrix complex collision
        -> explicit relational field
        -> CTMS recursive refinement
        -> token emission

    The model can also carry compressed RelationalMemory across chunks.
    """
    def __init__(self, cfg: RVIConfig):
        super().__init__()
        cfg.validate()
        self.cfg = cfg

        self.tok = nn.Embedding(cfg.vocab_size, cfg.d_model)
        self.blocks = nn.ModuleList([Block(cfg) for _ in range(cfg.n_layers)])
        self.norm = nn.RMSNorm(cfg.d_model)
        self.lm_head = nn.Linear(cfg.d_model, cfg.vocab_size, bias=False)
        self.lm_head.weight = self.tok.weight

        self.transition_head = nn.Sequential(
            nn.RMSNorm(cfg.d_model),
            nn.Linear(cfg.d_model, cfg.d_model, bias=False),
        )

    def forward(
        self,
        input_ids,
        targets=None,
        matrix_labels: Optional[torch.Tensor] = None,
        operator_labels: Optional[torch.Tensor] = None,
        memory: Optional[RelationalMemory] = None,
        return_diagnostics: bool = False,
        return_memory: bool = False,
    ):
        B, T = input_ids.shape
        if T > self.cfg.max_seq_len:
            raise ValueError(f"sequence length {T} > max_seq_len {self.cfg.max_seq_len}")

        x = self.tok(input_ids)
        relational_field = None
        current_memory = memory
        diagnostics: List[Dict[str, torch.Tensor]] = []
        final_aux = None

        for block in self.blocks:
            x, relational_field, current_memory, diag, aux = block(
                x,
                previous_field=relational_field,
                memory=current_memory,
                causal=True,
            )
            diagnostics.append(diag)
            final_aux = aux

        x = self.norm(x)
        logits = self.lm_head(x)

        losses: Dict[str, torch.Tensor] = {}
        total_loss = None

        if targets is not None:
            losses["lm"] = F.cross_entropy(
                logits.reshape(-1, logits.size(-1)),
                targets.reshape(-1),
            )

        if (
            self.cfg.multimatrix_enabled
            and matrix_labels is not None
            and final_aux is not None
            and final_aux["router_logits"] is not None
        ):
            route_logits = final_aux["router_logits"].mean(dim=1)
            losses["matrix"] = F.binary_cross_entropy_with_logits(
                route_logits,
                matrix_labels.to(route_logits.dtype),
            )

        if (
            self.cfg.ctms_enabled
            and operator_labels is not None
            and final_aux is not None
            and final_aux["operator_logits"] is not None
        ):
            losses["operator"] = F.cross_entropy(
                final_aux["operator_logits"],
                operator_labels.long(),
            )

        # "Catch time on the wing": predict the next hidden state rather than
        # learning only the static state.
        if T > 1:
            pred_next = self.transition_head(x[:, :-1])
            losses["transition"] = F.smooth_l1_loss(
                pred_next,
                x[:, 1:].detach(),
            )

        # Prevent all meaning matrices from collapsing into one representation.
        if (
            self.cfg.multimatrix_enabled
            and final_aux is not None
            and final_aux["matrix_state"] is not None
        ):
            ms = final_aux["matrix_state"].mean(dim=2)  # [B,M,Dm]
            ms = F.normalize(ms, dim=-1)
            gram = ms @ ms.transpose(-2, -1)
            eye = torch.eye(gram.size(-1), device=gram.device, dtype=gram.dtype)[None]
            losses["diversity"] = ((gram - eye) ** 2).mean()

        if losses:
            weighted = []
            for name, value in losses.items():
                if name == "lm":
                    w = 1.0
                elif name == "matrix":
                    w = self.cfg.matrix_loss_weight
                elif name == "operator":
                    w = self.cfg.operator_loss_weight
                elif name == "transition":
                    w = self.cfg.transition_loss_weight
                elif name == "diversity":
                    w = self.cfg.diversity_loss_weight
                else:
                    w = 1.0
                weighted.append(w * value)
            total_loss = torch.stack(weighted).sum()

        if diagnostics:
            diagnostics[-1] = {
                **diagnostics[-1],
                **{f"loss_{k}": v.detach() for k, v in losses.items()},
            }

        if return_memory:
            if return_diagnostics:
                return logits, total_loss, diagnostics, current_memory
            return logits, total_loss, current_memory

        if return_diagnostics:
            return logits, total_loss, diagnostics
        return logits, total_loss

    @torch.no_grad()
    def generate(self, input_ids, max_new_tokens=64, temperature=0.8, top_k=50):
        self.eval()
        for _ in range(max_new_tokens):
            x = input_ids[:, -self.cfg.max_seq_len:]
            logits, _ = self(x)
            logits = logits[:, -1, :] / max(temperature, 1e-5)
            if top_k is not None:
                v, _ = torch.topk(logits, min(top_k, logits.size(-1)))
                logits[logits < v[:, [-1]]] = float("-inf")
            probs = torch.softmax(logits, dim=-1)
            nxt = torch.multinomial(probs, 1)
            input_ids = torch.cat([input_ids, nxt], dim=1)
        return input_ids

    @torch.no_grad()
    def encode_matrix_memory(
        self,
        input_ids: torch.Tensor,
        memory: Optional[RelationalMemory] = None,
    ) -> RelationalMemory:
        _, _, _, mem = self(
            input_ids,
            memory=memory,
            return_diagnostics=True,
            return_memory=True,
        )
        if mem is None:
            raise RuntimeError("matrix memory unavailable; multimatrix_enabled may be false")
        return mem.detach()


# Backwards-friendly alias.
RVITransformer = RVIMultiMatrixTransformer
