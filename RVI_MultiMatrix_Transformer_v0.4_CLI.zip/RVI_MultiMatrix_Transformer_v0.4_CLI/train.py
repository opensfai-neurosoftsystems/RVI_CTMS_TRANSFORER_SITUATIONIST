import argparse
import json
from pathlib import Path

import torch

from rvi_multimatrix import RVIMultiMatrixTransformer, RVIConfig, ByteTokenizer
from rvi_multimatrix.corpus import (
    load_jsonl,
    sample_annotated_batch,
    plain_text_tensor,
    sample_plain_batch,
)


def main():
    ap = argparse.ArgumentParser()
    src = ap.add_mutually_exclusive_group(required=True)
    src.add_argument("--text")
    src.add_argument("--jsonl")

    ap.add_argument("--config", default="config.json")
    ap.add_argument("--steps", type=int, default=1000)
    ap.add_argument("--batch-size", type=int, default=8)
    ap.add_argument("--seq-len", type=int, default=256)
    ap.add_argument("--lr", type=float, default=3e-4)
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    ap.add_argument("--compile", action="store_true")
    ap.add_argument("--out", default="checkpoint_v03.pt")
    args = ap.parse_args()

    cfg = RVIConfig(**json.loads(Path(args.config).read_text()))
    tok = ByteTokenizer()

    records = None
    data = None
    if args.jsonl:
        records = load_jsonl(args.jsonl)
    else:
        data = plain_text_tensor(args.text, tok)
        if len(data) < args.seq_len + 2:
            raise ValueError("training text is shorter than seq_len")

    model = RVIMultiMatrixTransformer(cfg).to(args.device)
    if args.compile and hasattr(torch, "compile"):
        model = torch.compile(model)

    opt = torch.optim.AdamW(
        model.parameters(),
        lr=args.lr,
        betas=(0.9, 0.95),
        weight_decay=0.1,
    )

    model.train()
    for step in range(1, args.steps + 1):
        if records is not None:
            x, y, matrix_labels, operator_labels = sample_annotated_batch(
                records,
                cfg,
                args.batch_size,
                args.seq_len,
                args.device,
                tok,
            )
            _, loss, diag = model(
                x,
                y,
                matrix_labels=matrix_labels,
                operator_labels=operator_labels,
                return_diagnostics=True,
            )
        else:
            x, y = sample_plain_batch(data, args.batch_size, args.seq_len, args.device)
            _, loss, diag = model(x, y, return_diagnostics=True)

        opt.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()

        if step == 1 or step % 50 == 0:
            d = diag[-1] if diag else {}
            fields = []
            for k, v in d.items():
                if torch.is_tensor(v) and v.numel() == 1:
                    fields.append(f"{k}={float(v):.4f}")
            print(f"step={step} total_loss={loss.item():.4f} " + " ".join(fields))

    bare = model._orig_mod if hasattr(model, "_orig_mod") else model
    torch.save({
        "config": bare.cfg.__dict__,
        "model": bare.state_dict(),
    }, args.out)
    print("saved", args.out)


if __name__ == "__main__":
    main()
