import torch

from rvi_multimatrix import (
    RVIConfig,
    RVIMultiMatrixTransformer,
    RVIMultiMatrixEncoder,
    NeuralDAC,
    DACConfig,
)


cfg = RVIConfig(
    d_model=64,
    n_heads=4,
    n_layers=2,
    d_ff=128,
    max_seq_len=64,
    rvi_rank=8,
    matrix_names=[
        "semantic", "temporal", "spatial", "contradiction"
    ],
    matrix_dim=16,
    matrix_top_k=2,
    ctms_recurse=2,
)

x = torch.randint(0, 256, (2, 24))
y = torch.randint(0, 256, (2, 24))

matrix_labels = torch.tensor([
    [1, 1, 0, 1],
    [1, 0, 1, 0],
], dtype=torch.float32)
operator_labels = torch.tensor([3, 4])

m = RVIMultiMatrixTransformer(cfg)
logits, loss, diagnostics, memory = m(
    x,
    y,
    matrix_labels=matrix_labels,
    operator_labels=operator_labels,
    return_diagnostics=True,
    return_memory=True,
)

assert logits.shape == (2, 24, 256)
assert torch.isfinite(loss)
assert memory.matrix_summary.shape == (2, 4, 16)
assert diagnostics[-1]["rvi_field_std"].isfinite()
loss.backward()

# Cross-chunk relational memory.
x2 = torch.randint(0, 256, (2, 16))
_, loss2, diagnostics2, memory2 = m(
    x2,
    x2,
    memory=memory.detach(),
    return_diagnostics=True,
    return_memory=True,
)
assert memory2.matrix_summary.shape == memory.matrix_summary.shape
assert torch.isfinite(loss2)

# Bidirectional encoder.
enc = RVIMultiMatrixEncoder(cfg)
seq, pooled, emem, ediag = enc(x, return_diagnostics=True)
assert seq.shape == (2, 24, 64)
assert pooled.shape == (2, 64)
assert emem.matrix_summary.shape == (2, 4, 16)

# Neural DAC.
dac = NeuralDAC(DACConfig(
    d_model=64,
    hop_length=32,
    harmonics=8,
))
pcm, controls = dac(seq)
assert pcm.shape == (2, 24 * 32)
assert torch.isfinite(pcm).all()
assert pcm.abs().max() <= 1.0 + 1e-6

print(
    "V0.3 FULL STACK PASS",
    logits.shape,
    memory.matrix_summary.shape,
    seq.shape,
    pcm.shape,
)
